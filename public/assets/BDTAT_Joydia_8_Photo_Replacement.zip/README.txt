BDTAT Joydia Baor 8-photo replacement

Extract contents into the root of the BDTAT repository (sumonprojectormy-a11y/bdtat). Run python apply_joydia_photo_update.py, then git add content/blog.html public/assets/joydia-baor/ && git commit -m "Replace Joydia Baor blog photos" && git push. The site must redeploy to publish. These are the exact eight user-submitted images, not the older seventeen-image collection.

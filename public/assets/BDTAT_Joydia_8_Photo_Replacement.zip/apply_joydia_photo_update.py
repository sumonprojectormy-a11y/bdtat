from pathlib import Path
import re
p=Path('content/blog.html')
if not p.is_file():raise SystemExit('Run at BDTAT repository root: content/blog.html missing')
s=p.read_text(encoding='utf-8')
start=s.find('<article class="blog-post" id="joydia-baor-jhenaidah-lotus-travel-guide"')
if start<0:raise SystemExit('Joydia article not found; stopped without modifying anything')
end=s.find('</article>',start)
if end<0:raise SystemExit('Article closing tag missing; stopped')
end+=len('</article>')
article=s[start:end]
article,n=re.subn(r'<figure class="blog-photo">.*?</figure>', '', article, flags=re.S)
if n<1:raise SystemExit('Expected old blog photos not found; stopped')
photos=[]
for i in range(1,9):
    src=f'/assets/joydia-baor/joydia-baor-{i:02d}.jpg'
    alt=f'Joydia Baor landscape reference image {i}, supplied by contributor'
    photos.append(f'<figure class="blog-photo"><img src="{src}" alt="{alt}" loading="lazy" decoding="async"><figcaption>Joydia Baor · ছবি {i} / Image {i}</figcaption></figure>')
block='\n<section class="joydia-photo-gallery" aria-label="Joydia Baor photo gallery">\n<h3>Joydia Baor Photo Gallery | জয়দিয়া বাঁওড় ছবির গ্যালারি</h3>\n'+ '\n'.join(photos)+'\n</section>\n'
needle='<p class="blog-date"><time datetime="2026-11-13">13 November 2026</time></p>'
if needle not in article:raise SystemExit('Expected blog date missing; stopped')
article=article.replace(needle,needle+block,1)
# These were already removed in GitHub, guard against regression without changing other FAQ.
article=re.sub(r'<p><strong>ব্লগের ছবিগুলো কি জয়দিয়া বাঁওড়ের\?</strong>.*?</p>','',article,flags=re.S)
article=re.sub(r'<p><strong>Are the images from Joydia Baor\?</strong>.*?</p>','',article,flags=re.S)
p.write_text(s[:start]+article+s[end:],encoding='utf-8')
print(f'Updated Joydia Baor gallery: removed {n} old figures; added {len(photos)} supplied photos')
